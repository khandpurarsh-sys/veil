package com.veil.privatecircle;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

// Opaque, independent launcher. TWA failure must never leave a silent blank icon.
public class StartActivity extends Activity {
 private static final String URL="https://khandpurarsh-sys.github.io/veil/app/";
 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(36,90,36,36);layout.setBackgroundColor(Color.BLACK);
  TextView title=new TextView(this);title.setText("Veil");title.setTextColor(Color.WHITE);title.setTextSize(30);layout.addView(title);
  TextView note=new TextView(this);note.setText("Opening your private circle. If it does not appear, open it with the same Chrome profile you used for Veil. Keep your browser data.");note.setTextColor(Color.LTGRAY);note.setTextSize(16);note.setPadding(0,30,0,30);layout.addView(note);
  Button open=new Button(this);open.setText("Open Veil in Chrome");open.setOnClickListener(v->openBrowser(note));layout.addView(open);
  Button retry=new Button(this);retry.setText("Try fullscreen again");retry.setOnClickListener(v->openTwa(note));layout.addView(retry);
  setContentView(layout);
  if(state==null&&!getIntent().getBooleanExtra("fallback",false))openTwa(note);
 }
 private void openTwa(TextView note){try{startActivity(new Intent(this,LauncherActivity.class));}catch(RuntimeException error){android.util.Log.e("VeilLaunch","TWA start failed",error);note.setText("Fullscreen could not start. Open Veil in Chrome below. Your browser keys have not changed.");}}
 private void openBrowser(TextView note){
  Intent web=new Intent(Intent.ACTION_VIEW,Uri.parse(URL));web.addCategory(Intent.CATEGORY_BROWSABLE);
  try{web.setPackage("com.android.chrome");startActivity(web);return;}catch(RuntimeException error){web.setPackage(null);}
  for(ResolveInfo candidate:getPackageManager().queryIntentActivities(web,0)){
   if(candidate.activityInfo.packageName.equals(getPackageName()))continue;
   try{web.setPackage(candidate.activityInfo.packageName);startActivity(web);return;}catch(RuntimeException ignored){}
  }
  note.setText("No browser could open. Enable or update Chrome, then tap Open Veil in Chrome. Do not clear browser data.");
 }
}
