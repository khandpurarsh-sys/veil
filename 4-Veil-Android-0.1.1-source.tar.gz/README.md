# Veil Android alpha 0.1.0

Browser-backed Trusted Web Activity for the real Veil web app at https://khandpurarsh-sys.github.io/veil/app/ . It uses the silver knot icon and sticky immersive fullscreen. Requires Android 7 or newer and an up-to-date compatible browser. Verification failure falls back to a browser tab with controls; it does not fall back to a WebView or move encryption keys.

The browser stores Veil's existing account and encryption keys. Use the same browser and profile as the installed web app. Do not clear browser storage or reinstall the web app to test this APK. If owner sign-in or key restore is requested unexpectedly, stop and check the selected browser/profile first.

No notifications, background message delivery or new native encryption are added. This is a development alpha, not independently security-reviewed.

Build: JDK17, Android SDK36, Gradle8.11.1, Android Gradle Plugin8.9.1, Android Browser Helper2.7.4. Run `./gradlew assembleRelease lintRelease`, align then sign the release APK. The signing recovery is privately saved and must never be committed to the repo.

Public signing certificate SHA256: 07:D4:1D:4D:BF:08:9C:EE:2C:EA:80:76:43:00:38:6C:BE:8C:CB:00:D8:1A:3B:AE:82:5A:D9:65:6F:53:8F:6D . The root-site Digital Asset Links file includes this certificate while preserving the DressJet entry.

## 0.1.1 launch-safety update
VersionCode2. Native StartActivity is now the opaque launcher, with a visible Chrome fallback and TWA retry. Startup RuntimeExceptions are logged under VeilLaunch. Release shrinking is disabled to remove R8 as a diagnostic variable. Same signing certificate. Android runtime is still unverified because the local emulator cannot start within available memory. Do not claim a confirmed root cause or 120Hz minimum.
